create
    definer = root@localhost procedure delete_product(IN proID int)
begin
    delete from products where Id = proID;
end;

