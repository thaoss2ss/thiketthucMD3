create
    definer = root@localhost procedure update_product(IN proID int, IN proCode varchar(50), IN proName varchar(255),
                                                      IN proPrice int, IN proAmount int, IN proDescription varchar(255),
                                                      IN proStatus varchar(255))
begin
    update products
    set productCode       = proCode,
        productName       = proName,
        productPrice      = proPrice,
        productAmount     = proAmount,
        productDescription=proDescription,
        productStatus     = proStatus
    where Id = proID;
end;

