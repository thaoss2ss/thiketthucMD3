create
    definer = root@localhost procedure informationProduct(IN value1 int, OUT value2 int)
begin
    set value2 = (select id, productcode, productname, productprice, productamount, productdescription, productstatus from Products where (id, productcode, productname, productprice, productamount, productdescription, productstatus) = value1);
end;

