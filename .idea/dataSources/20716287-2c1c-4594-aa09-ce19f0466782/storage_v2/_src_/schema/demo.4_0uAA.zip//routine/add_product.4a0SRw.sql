create
    definer = root@localhost procedure add_product(IN proCode varchar(50), IN proName varchar(255), IN proPrice int,
                                                   IN proAmount int, IN proDescription varchar(255),
                                                   IN proStatus varchar(255))
begin
    insert into Products (productCode, productName, productprice, productamount, productdescription, productStatus)
        values (proCode, proName, proPrice, proAmount, proDescription, proStatus);
end;

