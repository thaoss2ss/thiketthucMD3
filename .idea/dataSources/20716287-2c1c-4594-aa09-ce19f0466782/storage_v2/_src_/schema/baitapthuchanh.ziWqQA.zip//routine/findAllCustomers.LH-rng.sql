create
    definer = root@localhost procedure findAllCustomers()
begin
    select * from customers where customerNumber = 175;
end;

